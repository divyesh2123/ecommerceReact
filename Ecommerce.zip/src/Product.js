import React from 'react'
import Header from './Header'
import ProductList from './ProductList'

export default function Product() {
  return (
    <div>

        <Header></Header>

        <ProductList></ProductList>



    </div>
  )
}
